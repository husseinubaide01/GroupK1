<?php 
session_start();
error_reporting(0);

//require "security.php";
//session_destroy();
//mysql_connect("localhost","spzd_event","spzd_event@#")||die("connection error");
//mysql_connect("localhost","root","")||die("connection error");
//mysql_select_db("spzd_event_management")||die("database error");

//$con = mysqli_connect("localhost","root","","spzd_event_management");
$con = mysqli_connect("localhost","phoenvac_booking","l8-)%5Mm3rxI","phoenvac_bookings");





?>