<div class="footer">
	<div class="container">
		<div class="row cus-row">
			<div class="col-sm-7">
				<p class="text-right">ADDRESS: 20 FARNDALE CRESCENT, LONDON, UB6 9RG</p>
			</div>
			
			<div class="col-sm-5">
				<p>EMAIL: bookasport@gmail.com</p>
			</div>
		</div>
	</div>
</div>


</body>
</html>